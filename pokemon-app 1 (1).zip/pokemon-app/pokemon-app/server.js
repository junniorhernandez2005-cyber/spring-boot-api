const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// Servir la vista del frontend
app.use(express.static(path.join(__dirname, 'public')));

// Base de datos en memoria para el CRUD local
let misPokemones = [];

// 1. READ ALL: Ver todos los Pokémones de la base de datos (Locales + PokéAPI)
app.get('/api/pokemones', async (req, res) => {
  try {
    const apiRes = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=12');
    const pokemonesApi = apiRes.data.results.map((p, index) => ({
      id: index + 1,
      nombre: p.name,
      origen: 'PokéAPI'
    }));

    const todos = [...misPokemones, ...pokemonesApi];
    res.json(todos);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener los Pokémones' });
  }
});

// 2. READ ONE: Consultar un Pokémon por nombre o ID
app.get('/api/pokemon/:busqueda', async (req, res) => {
  const { busqueda } = req.params;

  const local = misPokemones.find(p => p.nombre.toLowerCase() === busqueda.toLowerCase());
  if (local) return res.json(local);

  try {
    const apiRes = await axios.get(`https://pokeapi.co/api/v2/pokemon/${busqueda.toLowerCase()}`);
    const pokemon = {
      id: apiRes.data.id,
      nombre: apiRes.data.name,
      imagen: apiRes.data.sprites.front_default,
      tipos: apiRes.data.types.map(t => t.type.name),
      origen: 'PokéAPI'
    };
    res.json(pokemon);
  } catch (error) {
    res.status(404).json({ mensaje: 'Pokémon no encontrado' });
  }
});

// 3. CREATE: Guardar un nuevo Pokémon localmente
app.post('/api/pokemon', (req, res) => {
  const { nombre, tipos } = req.body;
  if (!nombre) return res.status(400).json({ mensaje: 'El nombre es obligatorio' });

  const nuevoPokemon = {
    id: Date.now(),
    nombre,
    imagen: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png',
    tipos: tipos ? tipos.split(',').map(t => t.trim()) : ['desconocido'],
    origen: 'Local'
  };

  misPokemones.push(nuevoPokemon);
  res.status(201).json({ mensaje: 'Pokémon creado exitosamente', pokemon: nuevoPokemon });
});

app.listen(3000, () => console.log('Servidor en http://localhost:3000'));